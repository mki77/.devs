7TSP DOWNLOAD:
	https://www.deviantart.com/devillnside/art/7TSP-GUI-2019-Edition-804769422

7TSP PACK FILES:
	.\Resources\*.res
		7TSP will recognize any dll/exe/cpl/mui file in .res format in this folder.
		Dark mode has its .res file, move it to 'Resources' from subfolder.
		New files must have all language IDs in English (1033).

	.\pack.ini
		[Base Pack]
		Pack=PACK_NAME
		Version=0.1
		[7tsp]
		theme=mytheme.theme (a custom theme file placed in the 'Extra' folder)
		uxhex=yes (in case the theme needs uxtheme.dll to be patched, else write 'no')
		mui=no

	7TSP files must be in a .7z archive with '7tsp' in the name.

NOTES:
	If you are updating a previous patch, remove all traces of it.
	Please apply .reg files and clear the thumbnail cache to fix missing icons.
	Further shortcomings can be solved using Winaero Tweaker.

LICENSE:
	These are free artwork, you can redistribute them and/or modify them under the
	terms of the GNU General Public License <http://www.gnu.org/licenses/>.
